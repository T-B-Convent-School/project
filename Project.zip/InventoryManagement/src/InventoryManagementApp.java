/**
 * Main class to start the Inventory Management System.
 */
public class InventoryManagementApp {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();
        manager.runMenu();
    }
}
